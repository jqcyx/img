// 引入对应的64种结果集
const resultMap = require('/data/result.js');

Page({
  data: {
    tossCount: 0,        // 抛掷次数 (0-3)
    isAnimating: false,  // 动画状态
    coin1: 1,            // 第一个硬币状态 1=up, 0=down
    coin2: 1,            // 第二个硬币状态 1=up, 0=down
    history: [] as number[], // 保存抛出历史，如 [1,0, 0,0, 1,1]
    
    binarySequence: '',  // 拼接出的二进制序列
    decimalResult: 0,    // 转换为十进制数值 (0-63)
    finalResultText: ''  // 最终显示的占卜文本
  },

  onToss() {
    if (this.data.isAnimating || this.data.tossCount >= 3) return;
  
    // 随机范围 -600 ~ -350（rpx）
    const MIN = -600, MAX = -350;
    const randomHeight = () => Math.round(Math.random() * (MAX - MIN) + MIN);
  
    // 生成两个独立高度
    const height1 = randomHeight();
    const height2 = randomHeight();
  
    // 更新高度并触发动画
    this.setData({
      tossHeight1: height1,
      tossHeight2: height2,
      isAnimating: true
    });
  
    // 动画结束后处理结果（与原逻辑完全一致）
    setTimeout(() => {
      const res1 = Math.random() >= 0.5 ? 1 : 0;
      const res2 = Math.random() >= 0.5 ? 1 : 0;
      const newHistory = [...this.data.history, res1, res2];
      const newCount = this.data.tossCount + 1;
  
      this.setData({
        isAnimating: false,
        coin1: res1,
        coin2: res2,
        history: newHistory,
        tossCount: newCount
      });
  
      if (newCount === 3) {
        this.calculateResult(newHistory);
      }
    }, 1000); // 与动画时长匹配
  },
  calculateResult(history: number[]) {
    const binaryStr = history.join('');
    const decimalValue = parseInt(binaryStr, 2);

    const resultKey = decimalValue.toString();
    
    // 2. 这里直接使用获取到的字典
    const resultText = resultMap[resultKey] || "未配置对应的结果指示";

    this.setData({
      binarySequence: binaryStr,
      decimalResult: decimalValue,
      finalResultText: resultText
    });
  },

  // 重新开始
  onReset() {
    this.setData({
      tossCount: 0,
      isAnimating: false,
      coin1: 1, 
      coin2: 1,
      history: [],
      binarySequence: '',
      decimalResult: 0,
      finalResultText: ''
    });
  }
})